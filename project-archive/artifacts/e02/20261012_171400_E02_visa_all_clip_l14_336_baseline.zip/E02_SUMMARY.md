# E02 VisA Baseline Summary

- Run ID: `20261012_171400_E02_visa_all_clip_l14_336_baseline`
- Completed categories: 12/12
- Maximum absolute category-metric delta: 2.506154 percentage points
- Deltas above 0.10 percentage points: 25

## Reproduced Mean

- auroc_px: 98.713645
- f1_px: 48.900484
- ap_px: 45.383142
- aupro: 92.428779
- auroc_sp: 92.400077
- f1_sp: 88.797846
- ap_sp: 93.177198
