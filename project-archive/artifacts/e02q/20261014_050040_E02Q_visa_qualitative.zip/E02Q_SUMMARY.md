# E02Q VisA Qualitative Summary

- Run ID: `20261014_050040_E02Q_visa_qualitative`
- Source E02 Run ID: `20261012_171400_E02_visa_all_clip_l14_336_baseline`
- Categories: pcb2, pcb3, pcb4, fryum
- Selected cases: 24
- Maximum absolute metric delta from E02: 1.42108547152e-14 percentage points

## Selection Counts

- best_localization: 4
- false_negative_candidate: 8
- false_positive_candidate: 8
- worst_localization: 4
