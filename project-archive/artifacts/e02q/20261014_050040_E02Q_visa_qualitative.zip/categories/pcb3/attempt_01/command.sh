#!/usr/bin/env bash
set -euo pipefail
/usr/bin/python3 examples/musc_main.py --device 0 --data_path /content/visa-extract --dataset_name visa --class_name pcb3 --backbone_name ViT-L-14-336 --pretrained openai --feature_layers 5 11 17 23 --img_resize 518 --divide_num 1 --r_list 1 3 5 --batch_size 4 --output_dir /content/drive/MyDrive/CS2203_MuSc/runs/20261014_050040_E02Q_visa_qualitative/categories/pcb3/attempt_01/output --vis True --vis_type whole_norm --save_excel True
