# E04 MVTec AD Top-1-Percent Pooling Summary

- Run ID: `20261016_102025_E04_mvtec_top1_pooling`
- Completed categories: 15/15
- Baseline continuity maximum mean delta: 0.000000 percentage points
- Total subprocess runtime: 123.56 minutes

## Macro Metrics

   variant  auroc_sp     f1_sp     ap_sp
   max_raw 97.386429 96.735510 98.725792
 max_rscin 97.734031 97.405687 99.052802
  top1_raw 97.022677 96.879586 98.824591
top1_rscin 96.781102 96.974682 98.776612

## Mean Pooling Deltas

- auroc_sp_top1_minus_max_raw: -0.363752
- auroc_sp_top1_minus_max_rscin: -0.952929
- f1_sp_top1_minus_max_raw: +0.144076
- f1_sp_top1_minus_max_rscin: -0.431005
- ap_sp_top1_minus_max_raw: +0.098799
- ap_sp_top1_minus_max_rscin: -0.276190

## Interpretation Guardrails

- Pixel-level metrics are controls, not E04 outcomes.
- F1-max thresholds are selected post hoc from benchmark labels.
- A metric increase alone does not prove reduced isolated-noise sensitivity.
- Qualitative heatmaps are required for the proposed mechanism claim.
