#!/usr/bin/env bash
set -euo pipefail
/usr/bin/python3 examples/musc_main.py --device 0 --data_path /content/data --dataset_name mvtec_ad --class_name cable --backbone_name ViT-L-14-336 --pretrained openai --feature_layers 5 11 17 23 --img_resize 518 --divide_num 1 --r_list 1 3 5 --batch_size 4 --output_dir /content/drive/MyDrive/CS2203_MuSc/runs/20261012_074856_E01_mvtec_all_clip_l14_336_baseline/categories/cable/attempt_01/output --vis False --vis_type whole_norm --save_excel True
