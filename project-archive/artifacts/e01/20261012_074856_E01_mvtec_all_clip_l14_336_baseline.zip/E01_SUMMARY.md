# E01 MVTec AD Baseline Summary

- Run ID: `20261012_074856_E01_mvtec_all_clip_l14_336_baseline`
- Completed categories: 15/15
- Maximum absolute category-metric delta: 0.813780 percentage points
- Deltas above 0.10 percentage points: 10

## Reproduced Mean

- auroc_px: 97.114390
- f1_px: 62.157971
- ap_px: 62.261741
- aupro: 93.452960
- auroc_sp: 97.734031
- f1_sp: 97.405687
- ap_sp: 99.052802
